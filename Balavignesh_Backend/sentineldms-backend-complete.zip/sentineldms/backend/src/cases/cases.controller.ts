import { Body, Controller, Get, Param, Post, Put, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard.js';
import { CurrentUser } from '../auth/decorators/current-user.decorator.js';
import type { AuthenticatedUser } from '../auth/auth.service.js';
import { CasesService } from './cases.service.js';
import { CreateCaseDto } from './dto/create-case.dto.js';
import { UpdateCaseStatusDto } from './dto/update-case-status.dto.js';

@ApiTags('cases')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('cases')
export class CasesController {
  constructor(private readonly casesService: CasesService) {}

  @Post()
  @ApiOperation({ summary: 'Create case' })
  create(@Body() dto: CreateCaseDto, @CurrentUser() user: AuthenticatedUser) {
    return this.casesService.create(dto, user.id);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Case detail + linked documents' })
  findOne(@Param('id') id: string) {
    return this.casesService.findOne(id);
  }

  @Put(':id/status')
  @ApiOperation({ summary: 'Update case status' })
  updateStatus(@Param('id') id: string, @Body() dto: UpdateCaseStatusDto) {
    return this.casesService.updateStatus(id, dto);
  }
}
