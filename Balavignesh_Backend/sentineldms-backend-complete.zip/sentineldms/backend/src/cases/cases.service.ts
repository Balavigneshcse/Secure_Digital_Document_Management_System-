import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service.js';
import { CreateCaseDto } from './dto/create-case.dto.js';
import { UpdateCaseStatusDto } from './dto/update-case-status.dto.js';

@Injectable()
export class CasesService {
  constructor(private readonly prisma: PrismaService) {}

  create(dto: CreateCaseDto, createdById: string) {
    return this.prisma.case.create({
      data: { ...dto, createdById },
    });
  }

  async findOne(id: string) {
    const found = await this.prisma.case.findUnique({
      where: { id },
      include: { documents: true },
    });
    if (!found) throw new NotFoundException(`Case ${id} not found`);
    return found;
  }

  async updateStatus(id: string, dto: UpdateCaseStatusDto) {
    await this.findOne(id); // 404s early if missing
    return this.prisma.case.update({
      where: { id },
      data: { status: dto.status },
    });
  }
}
