import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service.js';

@Injectable()
export class NotificationsService {
  constructor(private readonly prisma: PrismaService) {}

  // Called by other modules (Workflow, Document) when something happens that
  // a user should know about — not exposed as its own POST endpoint.
  create(userId: string, message: string, resourceId?: string) {
    return this.prisma.notification.create({
      data: { userId, message, resourceId },
    });
  }

  findAllForUser(userId: string) {
    return this.prisma.notification.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
    });
  }

  markRead(id: string) {
    return this.prisma.notification.update({
      where: { id },
      data: { isRead: true },
    });
  }
}
