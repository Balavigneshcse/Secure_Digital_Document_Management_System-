import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { ApprovalStatus } from '@prisma/client';
import { IsEnum, IsIn, IsOptional, IsString } from 'class-validator';

export class DecideWorkflowApprovalDto {
  @ApiProperty({ enum: [ApprovalStatus.APPROVED, ApprovalStatus.REJECTED] })
  @IsEnum(ApprovalStatus)
  @IsIn([ApprovalStatus.APPROVED, ApprovalStatus.REJECTED])
  status: ApprovalStatus;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  comments?: string;
}
