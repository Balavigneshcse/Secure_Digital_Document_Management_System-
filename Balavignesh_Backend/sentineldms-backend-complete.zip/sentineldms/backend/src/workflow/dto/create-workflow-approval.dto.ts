import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty } from 'class-validator';

export class CreateWorkflowApprovalDto {
  @ApiProperty({ description: 'Case this approval step belongs to' })
  @IsString()
  @IsNotEmpty()
  caseId: string;

  @ApiProperty({ description: 'User who needs to approve/reject' })
  @IsString()
  @IsNotEmpty()
  approverId: string;
}
