import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service.js';
import { NotificationsService } from '../notifications/notifications.service.js';
import { CreateWorkflowApprovalDto } from './dto/create-workflow-approval.dto.js';
import { DecideWorkflowApprovalDto } from './dto/decide-workflow-approval.dto.js';

@Injectable()
export class WorkflowService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly notifications: NotificationsService,
  ) {}

  async create(dto: CreateWorkflowApprovalDto) {
    const approval = await this.prisma.workflowApproval.create({ data: dto });
    await this.notifications.create(
      dto.approverId,
      `You have a case pending your review: ${dto.caseId}`,
      dto.caseId,
    );
    return approval;
  }

  findForCase(caseId: string) {
    return this.prisma.workflowApproval.findMany({
      where: { caseId },
      orderBy: { createdAt: 'asc' },
    });
  }

  async decide(id: string, dto: DecideWorkflowApprovalDto) {
    const existing = await this.prisma.workflowApproval.findUnique({
      where: { id },
      include: { case: true },
    });
    if (!existing) throw new NotFoundException(`Workflow approval ${id} not found`);

    const updated = await this.prisma.workflowApproval.update({
      where: { id },
      data: { status: dto.status, comments: dto.comments },
    });

    await this.notifications.create(
      existing.case.createdById,
      `Case ${existing.case.caseNumber} was ${dto.status.toLowerCase()}`,
      existing.caseId,
    );

    return updated;
  }
}
