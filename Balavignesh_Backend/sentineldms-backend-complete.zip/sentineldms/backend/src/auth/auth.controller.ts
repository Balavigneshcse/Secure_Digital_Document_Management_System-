import { Controller, Get, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from './guards/jwt-auth.guard.js';
import { CurrentUser } from './decorators/current-user.decorator.js';
import type { AuthenticatedUser } from './auth.service.js';

@ApiTags('auth')
@ApiBearerAuth()
@Controller('auth')
export class AuthController {
  // Login itself happens against Keycloak directly (frontend redirects there,
  // or calls Keycloak's token endpoint) — this service only validates the
  // resulting JWT. That's why there's no POST /auth/login handler here.

  @Get('me')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: 'Current authenticated user + role' })
  me(@CurrentUser() user: AuthenticatedUser) {
    return user;
  }
}
