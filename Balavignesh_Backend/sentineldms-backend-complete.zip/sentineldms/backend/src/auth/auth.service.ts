import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service.js';
import { Role, User } from '@prisma/client';
import type { KeycloakJwtPayload } from './strategies/jwt.strategy.js';

export type AuthenticatedUser = User;

// Keycloak realm role names -> our internal Role enum.
// Dharani Dharan owns the realm config — confirm these role names match what's
// actually created in Keycloak before relying on this mapping in a demo.
const REALM_ROLE_MAP: Record<string, Role> = {
  officer: Role.OFFICER,
  judge: Role.JUDGE,
  forensic: Role.FORENSIC,
  admin: Role.ADMIN,
};

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(private readonly prisma: PrismaService) {}

  private resolveRole(realmRoles: string[]): Role {
    for (const realmRole of realmRoles) {
      const mapped = REALM_ROLE_MAP[realmRole.toLowerCase()];
      if (mapped) return mapped;
    }
    this.logger.warn(
      `No known role found in token realm_access.roles: [${realmRoles.join(', ')}] — defaulting to OFFICER`,
    );
    return Role.OFFICER;
  }

  // Called from JwtStrategy on every authenticated request. Upsert keeps the
  // local User row in sync with Keycloak without needing a separate provisioning step.
  async validateAndSyncUser(payload: KeycloakJwtPayload): Promise<AuthenticatedUser> {
    const role = this.resolveRole(payload.realm_access?.roles ?? []);

    return this.prisma.user.upsert({
      where: { id: payload.sub },
      update: {
        email: payload.email,
        name: payload.name ?? payload.preferred_username ?? payload.email,
        role,
      },
      create: {
        id: payload.sub,
        email: payload.email,
        name: payload.name ?? payload.preferred_username ?? payload.email,
        role,
      },
    });
  }
}
