import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ConfigService } from '@nestjs/config';
import { Strategy, ExtractJwt } from 'passport-jwt';
import jwksRsa from 'jwks-rsa';
import { AuthService } from '../auth.service.js';

// Shape of the claims Keycloak puts on an access token — trimmed to what we use.
export interface KeycloakJwtPayload {
  sub: string;
  email: string;
  preferred_username?: string;
  name?: string;
  realm_access?: { roles: string[] };
}

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy, 'jwt') {
  constructor(
    config: ConfigService,
    private readonly authService: AuthService,
  ) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKeyProvider: jwksRsa.passportJwtSecret({
        cache: true,
        rateLimit: true,
        jwksRequestsPerMinute: 5,
        jwksUri: config.get<string>('KEYCLOAK_JWKS_URI')!,
      }),
      issuer: config.get<string>('KEYCLOAK_ISSUER'),
      algorithms: ['RS256'],
    });
  }

  // Whatever this returns becomes `req.user` in every guarded route.
  // Syncing to the DB here (rather than in a separate step) keeps every
  // downstream module able to just trust req.user.role is current.
  async validate(payload: KeycloakJwtPayload) {
    return this.authService.validateAndSyncUser(payload);
  }
}
