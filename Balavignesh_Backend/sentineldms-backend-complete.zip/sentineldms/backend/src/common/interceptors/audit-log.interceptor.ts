import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { PrismaService } from '../../prisma/prisma.service.js';

const MUTATING_METHODS = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);

@Injectable()
export class AuditLogInterceptor implements NestInterceptor {
  constructor(private readonly prisma: PrismaService) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const request = context.switchToHttp().getRequest();
    const { method, url, params, user } = request;

    if (!MUTATING_METHODS.has(method) || !user?.id) {
      return next.handle();
    }

    return next.handle().pipe(
      tap(() => {
        // Fire-and-forget — an audit log failure should never fail the actual request.
        this.prisma.auditLog
          .create({
            data: {
              userId: user.id,
              action: `${method} ${url}`,
              resourceType: context.getClass().name.replace('Controller', ''),
              resourceId: params?.id ?? 'n/a',
            },
          })
          .catch(() => {
            // Deliberately swallowed — logging failures shouldn't surface to the client.
            // Swap for a real logger call once Arunkumar's schema is final.
          });
      }),
    );
  }
}
