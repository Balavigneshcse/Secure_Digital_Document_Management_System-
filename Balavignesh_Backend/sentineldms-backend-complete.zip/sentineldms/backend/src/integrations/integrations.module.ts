import { Global, Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { AiClientService } from './ai-client.service.js';
import { BlockchainClientService } from './blockchain-client.service.js';

@Global()
@Module({
  imports: [HttpModule],
  providers: [AiClientService, BlockchainClientService],
  exports: [AiClientService, BlockchainClientService],
})
export class IntegrationsModule {}
