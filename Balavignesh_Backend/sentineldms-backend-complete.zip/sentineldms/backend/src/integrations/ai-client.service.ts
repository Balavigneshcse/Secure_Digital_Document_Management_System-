import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';

// PROVISIONAL — replace with Deepak's real contract once he shares it (due end of Week 1).
export interface OcrClassifyResult {
  ocrText: string;
  docType: string; // e.g. "FIR" | "CHARGESHEET" | "WITNESS_STATEMENT" | "OTHER"
  entities: Record<string, unknown>;
}

@Injectable()
export class AiClientService {
  private readonly logger = new Logger(AiClientService.name);
  private readonly baseUrl: string;

  constructor(
    private readonly http: HttpService,
    private readonly config: ConfigService,
  ) {
    this.baseUrl = this.config.get<string>('AI_SERVICE_URL')!;
  }

  async ocrAndClassify(fileBuffer: Buffer, fileName: string, mimeType: string): Promise<OcrClassifyResult> {
    try {
      const { data } = await firstValueFrom(
        this.http.post<OcrClassifyResult>(
          `${this.baseUrl}/ocr-classify`,
          { fileName, mimeType, fileBase64: fileBuffer.toString('base64') },
          { timeout: 15000 },
        ),
      );
      return data;
    } catch (err) {
      this.logger.warn(
        `AI service unreachable at ${this.baseUrl} (${(err as Error).message}) — returning mock OCR/classify result. ` +
          `Swap this out once Deepak's service is live.`,
      );
      return {
        ocrText: '[mock OCR text — AI service not connected yet]',
        docType: 'OTHER',
        entities: {},
      };
    }
  }
}
