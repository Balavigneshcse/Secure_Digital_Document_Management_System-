import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';

// PROVISIONAL — replace with Dharani Dharan's real /blockchain/anchor and
// /blockchain/verify contract once shared (due end of Week 1).
export interface AnchorResult {
  txId: string;
}

export interface VerifyResult {
  isTampered: boolean;
  anchoredHash: string;
  checkedAt: string;
}

@Injectable()
export class BlockchainClientService {
  private readonly logger = new Logger(BlockchainClientService.name);
  private readonly baseUrl: string;

  constructor(
    private readonly http: HttpService,
    private readonly config: ConfigService,
  ) {
    this.baseUrl = this.config.get<string>('BLOCKCHAIN_SERVICE_URL')!;
  }

  async anchor(fileHash: string, documentId: string): Promise<AnchorResult> {
    try {
      const { data } = await firstValueFrom(
        this.http.post<AnchorResult>(
          `${this.baseUrl}/blockchain/anchor`,
          { fileHash, documentId },
          { timeout: 10000 },
        ),
      );
      return data;
    } catch (err) {
      this.logger.warn(
        `Blockchain service unreachable at ${this.baseUrl} (${(err as Error).message}) — returning mock tx id. ` +
          `Swap this out once Dharani Dharan's service is live.`,
      );
      return { txId: `mock-tx-${documentId}` };
    }
  }

  async verify(documentId: string, currentHash: string): Promise<VerifyResult> {
    try {
      const { data } = await firstValueFrom(
        this.http.get<VerifyResult>(`${this.baseUrl}/blockchain/verify`, {
          params: { documentId, currentHash },
          timeout: 10000,
        }),
      );
      return data;
    } catch (err) {
      this.logger.warn(
        `Blockchain service unreachable at ${this.baseUrl} (${(err as Error).message}) — returning mock "not tampered" result.`,
      );
      return { isTampered: false, anchoredHash: currentHash, checkedAt: new Date().toISOString() };
    }
  }
}
