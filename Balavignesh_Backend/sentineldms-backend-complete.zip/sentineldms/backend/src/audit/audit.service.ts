import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service.js';

export interface AuditLogQuery {
  userId?: string;
  resourceId?: string;
  from?: string;
  to?: string;
}

@Injectable()
export class AuditService {
  constructor(private readonly prisma: PrismaService) {}

  findAll(query: AuditLogQuery) {
    return this.prisma.auditLog.findMany({
      where: {
        userId: query.userId,
        resourceId: query.resourceId,
        createdAt: {
          gte: query.from ? new Date(query.from) : undefined,
          lte: query.to ? new Date(query.to) : undefined,
        },
      },
      orderBy: { createdAt: 'desc' },
      take: 200, // simple safety cap for the dashboard — add pagination if this grows
    });
  }
}
