import {
  Controller,
  Get,
  Post,
  Param,
  Query,
  UploadedFile,
  UseGuards,
  UseInterceptors,
  Body,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiConsumes, ApiOperation, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard.js';
import { CurrentUser } from '../auth/decorators/current-user.decorator.js';
import type { AuthenticatedUser } from '../auth/auth.service.js';
import { DocumentsService } from './documents.service.js';
import { UploadDocumentDto } from './dto/upload-document.dto.js';
import { SearchDocumentsDto } from './dto/search-documents.dto.js';

@ApiTags('documents')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('documents')
export class DocumentsController {
  constructor(private readonly documentsService: DocumentsService) {}

  @Post('upload')
  @ApiOperation({ summary: 'Multipart upload — kicks off OCR+classify+hash-anchor pipeline' })
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('file'))
  upload(
    @UploadedFile() file: Express.Multer.File,
    @Body() dto: UploadDocumentDto,
    @CurrentUser() user: AuthenticatedUser,
  ) {
    return this.documentsService.upload(file, user.id, dto.caseId);
  }

  // Declared before ':id' — otherwise Nest would try to match "search" as an :id param.
  @Get('search')
  @ApiOperation({ summary: 'Search documents by text, case, type, date range' })
  search(@Query() query: SearchDocumentsDto) {
    return this.documentsService.search(query);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Metadata + signed URL to file' })
  findOne(@Param('id') id: string) {
    return this.documentsService.findOne(id);
  }

  @Get(':id/versions')
  @ApiOperation({ summary: 'Version history' })
  findVersions(@Param('id') id: string) {
    return this.documentsService.findVersions(id);
  }

  @Get(':id/verify')
  @ApiOperation({ summary: 'Calls blockchain service, returns tamper status' })
  verify(@Param('id') id: string) {
    return this.documentsService.verify(id);
  }

  @Post(':id/sign')
  @ApiOperation({ summary: 'Apply digital signature (PKI service — stubbed until contract exists)' })
  sign(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.documentsService.sign(id, user.id);
  }
}
