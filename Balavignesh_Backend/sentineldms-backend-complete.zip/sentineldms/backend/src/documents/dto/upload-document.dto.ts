import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';

export class UploadDocumentDto {
  @ApiPropertyOptional({ description: 'Case to link this document to, if any' })
  @IsOptional()
  @IsString()
  caseId?: string;
}
