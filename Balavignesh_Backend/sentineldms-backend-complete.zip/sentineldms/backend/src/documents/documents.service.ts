import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { createHash } from 'crypto';
import { PrismaService } from '../prisma/prisma.service.js';
import { StorageService } from '../storage/storage.service.js';
import { AiClientService } from '../integrations/ai-client.service.js';
import { BlockchainClientService } from '../integrations/blockchain-client.service.js';

@Injectable()
export class DocumentsService {
  private readonly logger = new Logger(DocumentsService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly storage: StorageService,
    private readonly ai: AiClientService,
    private readonly blockchain: BlockchainClientService,
  ) {}

  // Mirrors the flow in the solution doc:
  // upload -> hash -> store -> OCR/classify -> anchor -> persist -> audit
  //
  // NOTE: this runs the AI call synchronously for now, which is fine for small
  // hackathon-scale files. If OCR starts taking more than a couple seconds,
  // move this onto the Redis/BullMQ queue instead of blocking the request —
  // see the note on this in the chat where this was scaffolded.
  async upload(
    file: Express.Multer.File,
    uploadedById: string,
    caseId: string | undefined,
  ) {
    const fileHash = createHash('sha256').update(file.buffer).digest('hex');
    const storageKey = await this.storage.uploadBuffer(file.buffer, file.originalname, file.mimetype);

    const [aiResult, anchorResult] = await Promise.all([
      this.ai.ocrAndClassify(file.buffer, file.originalname, file.mimetype),
      this.blockchain.anchor(fileHash, storageKey),
    ]);

    const document = await this.prisma.document.create({
      data: {
        caseId,
        fileName: file.originalname,
        mimeType: file.mimetype,
        storageKey,
        fileHash,
        docType: aiResult.docType,
        ocrText: aiResult.ocrText,
        entities: aiResult.entities,
        blockchainTxId: anchorResult.txId,
        uploadedById,
        versions: {
          create: {
            versionNumber: 1,
            storageKey,
            fileHash,
            blockchainTxId: anchorResult.txId,
            uploadedById,
          },
        },
      },
      include: { versions: true },
    });

    return document;
  }

  async findOne(id: string) {
    const doc = await this.prisma.document.findUnique({ where: { id } });
    if (!doc) throw new NotFoundException(`Document ${id} not found`);
    const signedUrl = await this.storage.getSignedUrl(doc.storageKey);
    return { ...doc, signedUrl };
  }

  async findVersions(id: string) {
    await this.findOne(id); // 404s early if the document doesn't exist
    return this.prisma.documentVersion.findMany({
      where: { documentId: id },
      orderBy: { versionNumber: 'asc' },
    });
  }

  async verify(id: string) {
    const doc = await this.findOne(id);
    return this.blockchain.verify(id, doc.fileHash);
  }

  // Stub — Dharani Dharan's PKI/e-signing contract isn't defined yet.
  // Swap the body of this once he shares the /pki/sign endpoint shape.
  async sign(id: string, _signedById: string) {
    await this.findOne(id);
    this.logger.warn(
      `sign() is a stub — wire this to Dharani Dharan's PKI service once its contract exists.`,
    );
    return this.prisma.document.update({
      where: { id },
      data: { isSigned: true },
    });
  }

  // Simple Postgres-backed search for now. Swap for a call into Deepak's
  // Elasticsearch-backed /search once that service exists — same query shape.
  async search(query: {
    q?: string;
    caseId?: string;
    type?: string;
    dateFrom?: string;
    dateTo?: string;
  }) {
    return this.prisma.document.findMany({
      where: {
        AND: [
          query.caseId ? { caseId: query.caseId } : {},
          query.type ? { docType: query.type } : {},
          query.q
            ? {
                OR: [
                  { fileName: { contains: query.q, mode: 'insensitive' } },
                  { ocrText: { contains: query.q, mode: 'insensitive' } },
                ],
              }
            : {},
          query.dateFrom ? { createdAt: { gte: new Date(query.dateFrom) } } : {},
          query.dateTo ? { createdAt: { lte: new Date(query.dateTo) } } : {},
        ],
      },
      orderBy: { createdAt: 'desc' },
    });
  }
}
