// Run with: npx prisma db seed
// Matches the 4 test users already in keycloak/realm-export.json (same ids
// aren't guaranteed to match Keycloak's real "sub" claims — once you log in
// through Keycloak for real, AuthService.validateAndSyncUser() will upsert
// the actual user row over these seeded ones, keyed by the real sub. These
// seeded ids are just stand-ins so Case/Document data has someone to belong
// to before anyone has logged in yet.
import { PrismaClient, Role, CaseStatus } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const officer = await prisma.user.upsert({
    where: { id: 'seed-officer1' },
    update: {},
    create: { id: 'seed-officer1', email: 'officer1@sentineldms.test', name: 'Test Officer', role: Role.OFFICER },
  });

  const judge = await prisma.user.upsert({
    where: { id: 'seed-judge1' },
    update: {},
    create: { id: 'seed-judge1', email: 'judge1@sentineldms.test', name: 'Test Judge', role: Role.JUDGE },
  });

  await prisma.user.upsert({
    where: { id: 'seed-forensic1' },
    update: {},
    create: { id: 'seed-forensic1', email: 'forensic1@sentineldms.test', name: 'Test Forensic', role: Role.FORENSIC },
  });

  await prisma.user.upsert({
    where: { id: 'seed-admin1' },
    update: {},
    create: { id: 'seed-admin1', email: 'admin1@sentineldms.test', name: 'Test Admin', role: Role.ADMIN },
  });

  const demoCase = await prisma.case.upsert({
    where: { caseNumber: 'FIR-2026-00142' },
    update: {},
    create: {
      caseNumber: 'FIR-2026-00142',
      title: 'Theft — MG Road branch',
      description: 'Seeded demo case for testing the API without uploading real files first.',
      status: CaseStatus.UNDER_REVIEW,
      createdById: officer.id,
    },
  });

  await prisma.workflowApproval.upsert({
    where: { id: 'seed-approval-1' },
    update: {},
    create: {
      id: 'seed-approval-1',
      caseId: demoCase.id,
      approverId: judge.id,
      status: 'PENDING',
    },
  });

  await prisma.notification.upsert({
    where: { id: 'seed-notification-1' },
    update: {},
    create: {
      id: 'seed-notification-1',
      userId: judge.id,
      message: `You have a case pending your review: ${demoCase.caseNumber}`,
      resourceId: demoCase.id,
    },
  });

  console.log('Seed complete:', { officer: officer.id, judge: judge.id, case: demoCase.id });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
