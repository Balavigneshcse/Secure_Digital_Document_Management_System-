# SentinelDMS

## First-time setup

```bash
# 1. Start shared infra (Postgres, Redis, MinIO, Keycloak)
docker compose up -d

# 2. Install backend deps
cd backend
npm install

# 3. Point Prisma at the DB and generate the client
npx prisma generate
npx prisma migrate dev --name init

# 4. (Optional) seed demo data — one user per role + a demo case, so Swagger
#    has something to query before you've uploaded anything real
npx prisma db seed

# 5. Run the API
npm run start:dev
```

- API: http://localhost:3000
- Swagger docs: http://localhost:3000/api-docs
- Health check: http://localhost:3000/health
- MinIO console: http://localhost:9001 (user: `sentinel_minio` / pass: `sentinel_minio_dev_pw`)
- Keycloak admin: http://localhost:8080 (user: `admin` / pass: `admin_dev_pw`)

`.env` is already set up (copied from `.env.example`) with values matching `docker-compose.yml` — no edits needed for local dev.

## Getting a token for Swagger / Postman testing

The starter Keycloak realm (`keycloak/realm-export.json`) ships with 4 test users, one per role, all with password `Password123!`:

| Username | Role |
|---|---|
| `officer1` | officer |
| `judge1` | judge |
| `forensic1` | forensic |
| `admin1` | admin |

Get an access token via the password grant (works because the client has `directAccessGrantsEnabled: true`):

```bash
curl -X POST http://localhost:8080/realms/sentineldms/protocol/openid-connect/token \
  -d "grant_type=password" \
  -d "client_id=sentineldms-backend" \
  -d "username=officer1" \
  -d "password=Password123!"
```

Copy the `access_token` from the response into Swagger's "Authorize" button, or as a Bearer token in Postman.

## What's already built

- **AuthModule** — validates Keycloak-issued JWTs against the realm's JWKS endpoint (no `nest-keycloak-connect` dependency — a self-contained passport strategy, so nothing here breaks if that package lags behind the NestJS version). Syncs the token into a local `User` row on every request, exposes `GET /auth/me`, plus `@Roles()` + `RolesGuard` for RBAC.
- **CasesModule** — `POST /cases`, `GET /cases/:id`, `PUT /cases/:id/status`.
- **DocumentsModule** — `POST /documents/upload` (hashes the file, stores it in MinIO, calls the AI and blockchain clients, saves a `Document` + first `DocumentVersion`), `GET /documents/:id`, `GET /documents/:id/versions`, `GET /documents/:id/verify`, `POST /documents/:id/sign` (stub), `GET /documents/search`.
- **WorkflowModule** — approval chain CRUD under `/workflow/approvals`, notifies the approver on creation and the case owner on decision.
- **NotificationsModule** — `GET /notifications`, `POST /notifications/:id/read`.
- **AuditModule** — `GET /audit-logs`, restricted to admin/judge. Every mutating request across the API is auto-logged by a global interceptor, so individual modules don't need to remember to call it.
- **StorageService** — thin MinIO wrapper, auto-creates the bucket on boot.
- **AiClientService / BlockchainClientService** — HTTP clients for Deepak's and Dharani Dharan's services. Both fall back to a clearly-labeled mock response if the real service isn't reachable yet, so the whole pipeline is testable end-to-end before Week 3–4 integration.
- **Global error handling** — every error response comes back in the same JSON shape (`statusCode`, `message`, `path`, `timestamp`) regardless of whether it's a validation error, a missing record, or a Prisma constraint violation.
- **helmet** — standard security headers on every response.
- **Prisma seed script** — `npx prisma db seed` creates a user per role plus a demo case, so there's something to query in Swagger before you've uploaded a real file.
- **Dockerfile** — production multi-stage build for when deployment week comes. Local dev still runs the backend on your host (`npm run start:dev`), not in Docker — only shared infra is containerized for local dev, so hot reload stays fast.

## Known placeholders — swap these once real contracts land

- `prisma/schema.prisma` — draft schema. Get Arunkumar's sign-off, then it's his to edit.
- `keycloak/realm-export.json` — starter realm so `docker compose up` works immediately. Replace with Dharani Dharan's real export once the realm/roles are finalized.
- `AiClientService` (`src/integrations/ai-client.service.ts`) — request/response shape is a guess. Update the `OcrClassifyResult` interface once Deepak shares his actual contract.
- `BlockchainClientService` (`src/integrations/blockchain-client.service.ts`) — same deal for Dharani Dharan's `/blockchain/anchor` and `/blockchain/verify`.
- `DocumentsService.sign()` — no PKI contract exists yet at all; currently just flips `isSigned` to `true`.

## A note on the OCR call

`DocumentsService.upload()` currently calls the AI service synchronously inside the request. That's fine for small hackathon-scale files, but if OCR starts taking more than a couple seconds, move it onto a Redis-backed queue (BullMQ, already have Redis running) so upload returns immediately and a background worker updates the document + fires a notification when classification finishes.

## Post the Swagger URL

Once `npm run start:dev` is running, post `http://localhost:3000/api-docs` in the team channel — Dineshkarthick is blocked on it for frontend work.
